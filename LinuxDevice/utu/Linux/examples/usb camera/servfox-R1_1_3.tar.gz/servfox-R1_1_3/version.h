 
 char version[] = "servfox version: 1.1.3 date: 11:12:2005 (C) mxhaard@magic.fr\0";
