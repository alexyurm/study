///////////////////////////////////////////////////////////////////
// FILE:      main.cpp
// CONTAINS:  template code for CPSC 314, Jan 2011, assignment 1
///////////////////////////////////////////////////////////////////

#ifdef WIN32
#include <windows.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>

float Fovy = 35.0;    // field of view  in the y-direction (in degrees)
int Width = 400;      // window width (pixels)
int Height = 400;     // window height (pixels)
float Znear = 1.0;    // near clipping plane (distance from camera)
float Zfar = 100.0;   // far clipping plane (distance from camera)
int iCount = 0;       // used for numbering the PPM image files
float Time = 0;       // initial time
float Dt = 0;         // time step
float AnimTimeStep = 0.01;
float DumpTimeStep = 0.03;

const int STRLEN = 300;            // maximum string length
typedef char STR[STRLEN];          // declare type STR for storing strings

const int PARAMS = 50;             // maximum number of animation paramters
float currKeyframe[PARAMS];        // current keyframe parameters
float prevKeyframe[PARAMS];        // previous keyframe parameteres
float Params[PARAMS];              // current parameters
int kfNum = 0;                     // number of current keyframe
bool Dump;                         // flag set to true when dumping animation frames

extern int dumpPPM(int);
void parse(char line[], char *parselist, int *argc, STR argv[]);
int readKeyframe();
void interpolate();     // interpolates between keyframes for current time
void drawCube(float sx, float sy, float sz);    // draw cube of given size

///////////////////////////////////////////////////////////////////
// FUNC:  displayCallback()
// DOES:  clears screen, draws the world, swaps buffers
///////////////////////////////////////////////////////////////////																										

void displayCallback(void)
{
	float eye[] = {-6,8,20};
	float center[] = {0,0,0};
	float up[] = {0,1,0};

		// clear drawing buffer
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	  // setup ModelView matrix with the viewmatrix
	  // i.e., set the camera position
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(eye[0],eye[1],eye[2],
		center[0],center[1],center[2],
		up[0],up[1], up[2]);

	  // draw a wire-frame sphere;  turn off lighting in order to get solid shading
	glDisable(GL_LIGHTING);
	glColor3f(1,1,1);
	glutWireSphere(1,20,10);     // sphere: r=1, 20 slices, 10 stacks
	glEnable(GL_LIGHTING);

	glPushMatrix(); 
	  // draw some colored teapots
	glTranslatef(-3,0,1);
	glColor3f(1,0.5,0.5);      // mostly red
	glutSolidTeapot(1.0);

	glTranslatef(3,0,0);
	glColor3f(0.5,1,0.5);      // mostly green
	glutSolidTeapot(1.0);
	
	glTranslatef(3,0,0);
	glColor3f(0.5,0.5,1);      // mostly blue
	glutSolidTeapot(1.0);

	glPopMatrix();

	  // draw ground plane
	glColor3f(1,1,1);          // white (greyish after lighting)
	glNormal3f(0,1,0);
	glBegin(GL_POLYGON);
	glVertex3f(-10,0,-10);
	glVertex3f(-10,0,10);
	glVertex3f(10,0,10);
	glVertex3f(10,0,-10);
	glEnd();

	  // draw simple figure with one arm
	glColor3f(0,1,1);
	glPushMatrix();

	glTranslatef(0,0,3);
	drawCube(2,3,0.5);

	glTranslatef(1,2.5,0);   // draw upper arm
	glRotatef(-90 + Params[2],0,0,1);    // rotate into position
	drawCube(0.5,2,0.5);

	glTranslatef(0,2,0);      // draw lower arm
	glRotatef(Params[3],0,0,1);      // bend at elbow
	drawCube(0.5,2,0.5);

	glPopMatrix();

	glutSwapBuffers();
	if (Dump) {               // save images to file
		dumpPPM(iCount);
		iCount++;
	}
}

///////////////////////////////////////////////////////////////////
// FUNC:  keyCallback()
// DOES:  handles glut keyboard events
///////////////////////////////////////////////////////////////////																										

void keyCallback(unsigned char key, int x, int y)
{
	switch(key) {
	case 'q': 
		exit(0);
		break;
	case 'i':
		dumpPPM(iCount);
		iCount++;
		break;
	case 'k':           // read in a keyframe
		readKeyframe();
		Time = currKeyframe[1];     // time parameter
		break;
	case 'a':
		Time = 0;           // set global time to zero
		Dt = AnimTimeStep;      // time step
		break;
	case 'd':               // dump animation PPM frames
		Time = 0;           // set global time to zero
		iCount = 0;         // image file count
		Dt = DumpTimeStep;      // time step
		Dump = true;
		break;
	case ' ':
		Dt = 0;        // stop animation
		break;
	default:
		break;
	}
	glutPostRedisplay();
}

///////////////////////////////////////////////////////////////////
// FUNC:  drawCube()
// DOES:  draws a cube of unit size, with x,y in [-0.5,0.5] and z in [0,1]
//
//                 5------------------6
//                /.                 /|
//               / .                / |
//              /  .               /  |
//             /   .              /   |
//            /    .             /    |
//           /     .            /     |
//          /      .           /      |
//         3------------------2       |
//         |       .          |       |
//         |       4..........|.......7
//         |      .           |      / 
//         |     .    y|      |     /  
//         |    .      |      |    /   
//         |   .       *----x |   /    
//         |  .       /       |  /     
//         | .     z /        | /      
//         |.                 |/       
//         0------------------1
//     
///////////////////////////////////////////////////////////////////																										

void drawCube(float sx, float sy, float sz)
{
	const float MINX = -0.5;
	const float MAXX = 0.5;
	const float MINY = 0;
	const float MAXY = 1;
	const float MINZ = -0.5;
	const float MAXZ = 0.5;

	  // 8 cube vertices
	float vertex[8][3] = {
		MINX, MINY, MAXZ,   // 0
		MAXX, MINY, MAXZ,   // 1
		MAXX, MAXY, MAXZ,   // 2 
		MINX, MAXY, MAXZ,   // 3
		MINX, MINY, MINZ,   // 4
		MINX, MAXY, MINZ,   // 5
		MAXX, MAXY, MINZ,   // 6
		MAXX, MINY, MINZ,   // 7
	};
	int faceV[6][4] = {      // vertices in counter-clockwise order
		0,1,2,3,   // front face
	    4,5,6,7,   // back face
		1,7,6,2,   // right face
		0,3,5,4,   // left face
		3,2,6,5,   // top face
		1,0,4,7    // bottom face
	};
	float faceN[6][3] = {
		
	    0,0,1,    // front face
		0,0,-1,   // back face
		1,0,0,    // right face
		-1,0,0,   // left face
		0,1,0,    // top face
		0,-1,0,   // bottom face
	};

	glPushMatrix();
	glScalef(sx,sy,sz);     // scale cube to the desired size
	for (int f=0; f<6; f++) {
		glBegin(GL_POLYGON);
		  // 3D normal (used by OpenGL for lighting)
		  // This becomes the 'current normal' that is assigned
		  // to all the following vertices
		glNormal3fv( faceN[f] );		                       
		for (int v=0; v<4; v++) {
			int i = faceV[f][v];      // vertex number
			glVertex3fv( vertex[i] );  // 3D vertex coords
		}
		glEnd();
	}
	glPopMatrix();
}

///////////////////////////////////////////////////////////////////
// FUNC:  readKeyframe()
// DOES:  read in next keyframe
///////////////////////////////////////////////////////////////////																										

int readKeyframe()
{
	static FILE *fp = NULL;
	char fname[] = "keyframe.txt";
	int n;
	STR line;
	int nargs;          // number of arguments
	STR args[PARAMS];   // arguments for parameters read in from a line

	  // open keyframe file
	if (!fp) {
		fp = fopen(fname,"r");
		if (!fp) {
			printf("Unable to open file '%s'\n",fname);
			return(1);     // flag error
		}
	}

	  // loop until a valid keyframe line is read in
	while (1) {
		fgets(line, STRLEN, fp);       // read line from file
		if (feof(fp)) {                // reached end-of-file ?
			fseek(fp,0,SEEK_SET);
			kfNum = 0;                 // reset keyframe number
			for (n=0; n<PARAMS; n++)
				currKeyframe[n] = 0;   // reset all keyframe params
			printf("\n");
			continue;                  // try again
		}
		parse(line," \n",&nargs, args);
		if (nargs==0)                  // no valid arguments ?
			continue; 
		kfNum++;                       // valid keyframe
		break;                         // break out of while-loop
	}

	  // read values from line into parameters
	printf("keyframe %d:", kfNum);
	for (n=1; n<nargs; n++) {
		prevKeyframe[n] = currKeyframe[n];
		float val = atof( args[n] );
		Params[n] = currKeyframe[n] = val;
		printf("%6.3f ", val);
	}
	currKeyframe[1] += prevKeyframe[1];      // time parameter is relative to the previous keyframe
	printf("\n");
	return(0);
}

///////////////////////////////////////////////////////////////////
// FUNC:  interpolate()
// DOES:  interpolates for current time
///////////////////////////////////////////////////////////////////																										

void interpolate()
{
	float wCurr, wPrev;
	wCurr = (Time - prevKeyframe[1]) / ( currKeyframe[1] - prevKeyframe[1] );
	wPrev = 1.0 - wCurr;
	for (int n=0; n<PARAMS; n++) {
		Params[n] = wPrev*prevKeyframe[n] + wCurr*currKeyframe[n]; 
	}
}

///////////////////////////////////////////////////////////////////
// FUNC:  myReshape()
// DOES:  this is called if the on-screen window is resized
///////////////////////////////////////////////////////////////////																										

void myReshape(int w, int h)
{
   Width = w;
   Height = h;
   glViewport(0, 0, w, h);
   glMatrixMode(GL_PROJECTION); 
   glLoadIdentity();
   gluPerspective(Fovy, (GLfloat) w/h, 1.0, 100.0);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}

///////////////////////////////////////////////////////////////////
// FUNC:  idleCallback()
// DOES:  glut calls this when idle;  used for animation
///////////////////////////////////////////////////////////////////																										

void idleCallback()
{
	const float MAXANGLE = 15;
	static float dAngle = 0.2;

	if (Dt==0) return;        // skip if not animating
	Time += Dt;    // increment current time by Dt (default Dt=0)
//	printf("  Time=%6.3f\n",Time);

	if (Time>currKeyframe[1]) {
		readKeyframe();
		if (currKeyframe[1] == 0.0) {    // reached end of animation ?
			Dump = false;                // stop image dumping
			Dt = 0;
			Time = 0;
			readKeyframe();
		}
	}

	  // interpolate animation parameters for current parameters
	interpolate();

	glutPostRedisplay();
}

///////////////////////////////////////////////////////////////////
// FUNC:  init()
// DOES:  initializes default light source and surface material
///////////////////////////////////////////////////////////////////																										

void init(void) 
{
   glClearColor (0.2f, 0.3f, 0.4f, 1.0);
   glShadeModel (GL_SMOOTH);

   glEnable(GL_LIGHTING);
   glEnable(GL_LIGHT0);
   glEnable(GL_DEPTH_TEST);
   glEnable(GL_COLOR_MATERIAL);
   glEnable(GL_NORMALIZE);

   for (int n=0; n<PARAMS; n++)    // init all keyframe params to zero
	   currKeyframe[PARAMS]= 0;     

      // read the first two keyframes
   readKeyframe();
   readKeyframe();
   interpolate();
}

///////////////////////////////////////////////////////////////////
// FUNC:  main()
// DOES:  intializes glut window, calls init(), then hands over control to glut
///////////////////////////////////////////////////////////////////																										

int main(int argc, char **argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(Width, Height);
   glutCreateWindow("Light Lab");
   glutReshapeFunc(myReshape);
   glutDisplayFunc(displayCallback);
   glutKeyboardFunc(keyCallback);
   glutIdleFunc(idleCallback);
   init();
   glutMainLoop();
   return 0;
}

///////////////////////////////////////////////////////////
//  PROC: dumpPPM()
//  DOES: saves screen contents as a PPM file
///////////////////////////////////////////////////////////

int dumpPPM(int frameNum)
{
  FILE *fp;
  const int maxVal=255;
  register int y;
  unsigned char *pixels;

  glReadBuffer( GL_FRONT );
  char fname[100];
  sprintf(fname,"/tmp/cs314/ppm/img%03d.ppm",frameNum);
  fp = fopen(fname,"wb");
  if (!fp) {
	printf("Unable to open file '%s'\n",fname);
	return 1;
  }
  printf("Saving image `%s`\n",fname);
  fprintf(fp, "P6 ");
  fprintf(fp, "%d %d ", Width, Height);
  fprintf(fp, "%d", maxVal);
  putc(13,fp);
  pixels = new unsigned char [3*Width];

  y = 0;
  glReadPixels(0,Height-1,Width,1,GL_RGB,GL_UNSIGNED_BYTE, (GLvoid *) pixels);

  for ( y = Height-1; y >=0; y-- ) {
	glReadPixels(0,y,Width,1,GL_RGB,GL_UNSIGNED_BYTE, (GLvoid *) pixels);
	for (int n=0; n<3*Width; n++) {
		putc(pixels[n],fp);
	}
  }
  fclose(fp);
  delete [] pixels;
  return 0;
}

/////////////////////////////////////////
//      PROC:   parse
//      DOES:   parses items in a string, places results in args
/////////////////////////////////////////

void parse(char line[], char *parselist, int *argc, STR argv[])
{
        int     indx=0;
        int     copying = 0;
        int     narg=0;
        int     argch=0;
        char    ch;

        while (line[indx]) {
                ch = line[indx++];
                if (ch=='#') break;
                if ( strchr(parselist,ch)) {
                        if (copying) {
                                copying=0;
                                argv[narg][argch]=0;
                                narg++;
                                argch=0;
                        }
                } else {
                        if (!copying) copying=1;
                        argv[narg][argch++] = ch;
                }
        }
        if (copying) {
                argv[narg][argch] = 0;
                *argc = ++narg;
        } else *argc = narg;
}

