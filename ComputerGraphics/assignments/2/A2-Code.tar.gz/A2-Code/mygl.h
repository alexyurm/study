//////////////////////////////////////////////////////////////////
// FILE:     mygl.h
// CONTAINS  defs of all the myGl functions
//////////////////////////////////////////////////////////////////

void myBegin(int type);
void myEnd();
void myVertex(float x, float y, float z);
void myColor(float r, float g, float b);
void myLoadIdentity();
void myTexCoord(float s, float t);
void myLookAt(float ex, float ey, float ez, float cx, float cy, float cz,
			  float vx, float vy, float vz);
void myFrustum(float left, float right, float bot, float top, float nr, float fr);
void myTranslate(float tx, float ty, float tz);
void myRotate(float th, float ax, float ay, float az);
void myScale(float sx, float sy, float sz);
void myMultMatrix(Matrix m);


