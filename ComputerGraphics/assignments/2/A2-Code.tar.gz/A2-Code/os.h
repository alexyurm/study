#ifdef WIN32
#include <windows.h>
#include <locale.h>
#define M_PI 3.1415926
#else
#include <string.h>
#endif
