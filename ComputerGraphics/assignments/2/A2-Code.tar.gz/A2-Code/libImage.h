////////////////////////////////////////////////////////////
//	FILE:		libImage.h
//	CONTAINS:	functions for reading / writing images
////////////////////////////////////////////////////////////

char *mymalloc(int size);       
IMAGE *find_image(char *name);
IMAGE *newimage(char *name);
void read_ppm_image(IMAGE *image, FILE *fp);
void getTexel(IMAGE *i, float u, float v, float &r, float &g, float &b);










