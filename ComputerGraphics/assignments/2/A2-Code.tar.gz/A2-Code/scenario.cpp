////////////////////////////////////////////////////////////////
// FILE:      scenario.cpp
// CONTAINS:  various display tests
////////////////////////////////////////////////////////////////

#include "os.h"
#include "GL/gl.h"
#include "GL/glut.h"
#include "libDefs.h"
#include "mygl.h"

extern void myBindTexture(char *name);
extern int Grid;
extern void DrawPixelGrid();
extern void initZbuffer();

////////////////////////////////////////////////////////////////
// FUNC:  scenario_A()
// DOES:  basic test of transformations: modelview + proj + /h + viewport
////////////////////////////////////////////////////////////////

void scenario_A()
{
	myLoadIdentity();

	myBegin(GL_POINTS);
	
	myColor(0,0,1);       // blue
	myVertex(0,0,0);      // center of screen in NDCS
	
	myColor(0,1,0);       // green 
	myVertex(0.5,0,0);    // off to the right
	
	myColor(1,0,0);       // red
	myVertex(0.5,0.5,0);  // off to the right and up
	
	myEnd();
}

////////////////////////////////////////////////////////////////
// FUNC:  scenario_B()
// DOES:  basic test of viewport transformation
////////////////////////////////////////////////////////////////

void scenario_B()
{
	myLoadIdentity();

	myColor(1,0,0);
	myBegin(GL_TRIANGLES);
	myVertex(0,0,0);
	myVertex(0.5,0,0);
	myVertex(0.5,0.5,0);	
	myEnd();

	myBegin(GL_POINTS);
	myColor(0,0,1);       // blue
	myVertex(0,0,0);      // center of screen in NDCS
	myColor(0,1,0);       // green 
	myVertex(0.5,0,0);    // off to the right
	myColor(1,0,0);       // red
	myVertex(0.5,0.5,0);  // off to the right and up
	myEnd();

	  // partly off-screen triangle to test clipping
	myColor(0,0,1);
	myBegin(GL_TRIANGLES);
	myVertex(-0.5,0.5,0);
	myVertex(-0.5,-0.5,0);
	myVertex(-1.5,0,0);
	myEnd();
}

////////////////////////////////////////////////////////////////
// FUNC:  scenario_C()
// DOES:  test of colour interpolation
////////////////////////////////////////////////////////////////

void scenario_C()
{
	myLoadIdentity();

	myBegin(GL_TRIANGLES);
	myColor(0,0,1);       // blue
	myVertex(0,0,0);      // center of screen in NDCS
	myColor(0,1,0);       // green 
	myVertex(0.5,0,0);    // off to the right
	myColor(1,0,0);       // red
	myVertex(0.5,0.5,0);  // off to the right and up
	myEnd();
}

////////////////////////////////////////////////////////////////
// FUNC:  scenario_D()
// DOES:  test translation, rotate, and scale
////////////////////////////////////////////////////////////////

void scenario_D()
{
	scenario_C();
	myTranslate(0,-1,0);
	myRotate(90,0,0,1);
	myScale(2,2,2);

	myBegin(GL_TRIANGLES);
	myColor(1,0,0);       // red
	myVertex(0,0,0);      // center of screen in NDCS
	myColor(0,1,0);       // green 
	myVertex(0.5,0,0);    // off to the right
	myColor(0,0,1);       // blue
	myVertex(0.5,0.5,0);  // off to the right and up
	myEnd();
}

////////////////////////////////////////////////////////////////
// FUNC:  scenario_E()
// DOES:  test of viewing and projection transformations
////////////////////////////////////////////////////////////////

void scenario_E()
{
	myLoadIdentity();
	myFrustum(-0.5,0.5,-0.5,0.5,1,10);
	myLookAt(1,0,1,0,0,0,0,1,0);

	myBegin(GL_TRIANGLES);
	myColor(1,0,0);       // red
	myVertex(0,0,0);      // center of screen in NDCS
	myColor(0,1,0);       // green 
	myVertex(0.5,0,0);    // off to the right
	myColor(0,0,1);       // blue
	myVertex(0.5,0.5,0);  // off to the right and up
	myEnd();
}

////////////////////////////////////////////////////////////////
// FUNC:  scenario_F()
// DOES:  test of Z-buffer
////////////////////////////////////////////////////////////////

void scenario_F()
{
	for (int n=0; n<40; n++) {
		glClear( GL_COLOR_BUFFER_BIT );
		if (Grid) DrawPixelGrid();
		initZbuffer();

		myLoadIdentity();

		myRotate((n>20?40-n:n),1,1,1);

		myColor(0,1,0);       // blue
		myBegin(GL_TRIANGLES);
		myVertex(-1,1,1);      // center of screen in NDCS
		myVertex(1,1,1);    // off to the right
		myVertex(0,-1,-1);  // off to the right and up
		myEnd();

		myScale(0.5,0.5,0.5);
		myColor(1,0,0);       // red
		myBegin(GL_TRIANGLES);
		myVertex(-1,-1,0);      // center of screen in NDCS
		myVertex(1,-1,0);    // off to the right
		myVertex(1,1,0);  // off to the right and up
		myEnd();
		myBegin(GL_TRIANGLES);
		myVertex(-1,-1,0);      // center of screen in NDCS
		myVertex(1,1,0);    // off to the right
		myVertex(-1,1,0);  // off to the right and up
		myEnd();

		glutSwapBuffers();
	}
}

////////////////////////////////////////////////////////////////
// FUNC:  scenario_G()
// DOES:  test of texture mapping
////////////////////////////////////////////////////////////////

void scenario_G()
{
	for (int n=0; n<40; n++) {
		glClear( GL_COLOR_BUFFER_BIT );
		if (Grid) DrawPixelGrid();
		initZbuffer();

		myLoadIdentity();
		myFrustum(-0.5,0.5,-0.5,0.5,1,10);
		myLookAt(2,0,2,0,0,0,0,1,0);

		myRotate((n>20?40-n:n),1,1,1);

		myBindTexture("clocktower.ppm");

		myBegin(GL_TRIANGLES);
		myTexCoord(0,1);
		myVertex(-1,-1,0);      // center of screen in NDCS
		myTexCoord(1,1);
		myVertex(1,-1,0);    // off to the right
		myTexCoord(1,0);
		myVertex(1,1,0);  // off to the right and up
		myEnd();

		myBegin(GL_TRIANGLES);
		myTexCoord(0,1);
		myVertex(-1,-1,0);      // center of screen in NDCS
		myTexCoord(1,0);
		myVertex(1,1,0);    // off to the right
		myTexCoord(0,0);
		myVertex(-1,1,0);  // off to the right and up
		myEnd();

		glutSwapBuffers();
	}
	CurrTex = (IMAGE *) 0;    // disable textures
}

////////////////////////////////////////////////////////////////
// FUNC:  scenario_H()
// DOES:  your own scene
////////////////////////////////////////////////////////////////

void scenario_H()
{
	for (int n=0; n<40; n++) {
		glClear( GL_COLOR_BUFFER_BIT );
		if (Grid) DrawPixelGrid();
		initZbuffer();

		myLoadIdentity();
		myFrustum(-0.5,0.5,-0.5,0.5,1,10);
		myLookAt(2,0,2,0,0,0,0,1,0);

		myRotate((n>20?40-n:n),1,1,1);

		myBindTexture("brick.ppm");

		myBegin(GL_TRIANGLES);
		myTexCoord(0,1);
		myVertex(-1,-1,0);      // center of screen in NDCS
		myTexCoord(1,1);
		myVertex(1,-1,0);    // off to the right
		myTexCoord(1,0);
		myVertex(1,1,0);  // off to the right and up
		myEnd();

		myBegin(GL_TRIANGLES);
		myTexCoord(0,1);
		myVertex(-1,-1,0);      // center of screen in NDCS
		myTexCoord(1,0);
		myVertex(1,1,0);    // off to the right
		myTexCoord(0,0);
		myVertex(-1,1,0);  // off to the right and up
		myEnd();

		glutSwapBuffers();
	}
	CurrTex = (IMAGE *) 0;    // disable textures
}

////////////////////////////////////////////////////////////////
// FUNC:  scenario_I()
// DOES:  your own scene
////////////////////////////////////////////////////////////////

void scenario_I()
{
}
