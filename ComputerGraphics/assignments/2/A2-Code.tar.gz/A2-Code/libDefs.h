////////////////////////////////////////////////////////
// FILE:      lib_defs.h
// CONTAINS:  global definitions
////////////////////////////////////////////////////////

#include <stdio.h>
#include <math.h>
#define VECSIZE 4
#define MAX_ARGS 10
const float DEG_RAD = 3.1416f/180.0f;

typedef float FVEC[VECSIZE];
#define STRLEN 100
typedef char STR[STRLEN];
typedef float Matrix[4][4];

typedef struct image {
  int xsize,ysize;
  unsigned char *data;
  char name[80];
  int num;                 // image number for OpenGL
  int clamp;               // flag: clamp or repeat
  struct image *next;
} IMAGE;

extern IMAGE *find_image();
extern char *myMalloc();
extern int cerr(int argc, char **argv, char *errmsg);
extern void SetPixel(int x, int y, float r, float g, float b);

  // some global variables
extern bool PCTexMap;
extern IMAGE *Image;    // pointer to linked list of images read in (for texture maps)
extern int Win[2];      // Win[0] == width, Win[1] = height of on-screen window
extern int Image_num;   // current number
extern STR Image_name;  // name for image series
extern IMAGE *CurrTex;  // pointer to current texture; used when binding textures





