/////////////////////////////////////////////////////////////
// FILE:      mygl.cpp
// CONTAINS:  your implementations of various GL functions
////////////////////////////////////////////////////////////.

#include "os.h"
#include "GL/gl.h"
#include "libDefs.h"
#include "libMath.h"
#include "libImage.h"

  // the following are your screen dimensions that you will render to
extern int VirtWidth;   // virtual screen width
extern int VirtHeight;  // virtual screen height

  // array for the Z-buffer 
const int MAXPIX = 1000;
float Zbuf[MAXPIX][MAXPIX];         // z-buffer

// The following are global variables that you may find useful.
// You can delete, rename, or modify these as you wish

float CurrTexCoord[2];              // current texture coord
FVEC  CurrColor;                    // current color
Matrix ModelviewMatrix;             // ModelView matrix
Matrix ProjectionMatrix;            // Projection matrix

// Vertex data structure -- 
// You will want to create your own vertex data structure
// in order to store the following for each vertex:
//  -untransformed vertex coords
//  -transformed vertex coords
//  -color
//  -texture coords (only worry about this later)


//////////////////////////////////////////////////////
// FUNC:  myLoadIdentity() 
// DOES:  initializes both Modelview and Projection Matrices
//////////////////////////////////////////////////////

void myLoadIdentity()
{
	tmIden(ModelviewMatrix);
	tmIden(ProjectionMatrix);
}

//////////////////////////////////////////////////////
// FUNC:  myBegin(type) 
//////////////////////////////////////////////////////

void myBegin(int type)
{
}

//////////////////////////////////////////////////////
// FUNC:  myEnd() 
//////////////////////////////////////////////////////

void myEnd()
{
}

//////////////////////////////////////////////////////
// FUNC:  myVertex(x,y,z) 
//////////////////////////////////////////////////////

void myVertex(float x, float y, float z)
{
}

//////////////////////////////////////////////////////
// FUNC:  myColor(r,g,b)
//////////////////////////////////////////////////////

void myColor(float r, float g, float b)
{
}

//////////////////////////////////////////////////////
// FUNC:  myTexCoord(s,t) 
//////////////////////////////////////////////////////

void myTexCoord(float s, float t)
{
}

//////////////////////////////////////////////////////
// FUNC:  myLookAt(eye, center, Vup) 
//        Sets the ModelView matrix according to the given camera parameters.
//////////////////////////////////////////////////////

void myLookAt(float ex, float ey, float ez, float cx, float cy, float cz,
			  float vx, float vy, float vz)
{
}

//////////////////////////////////////////////////////
// FUNC:  myFrustum() 
//        Sets the Projection matrix according to the given frustum parameters.
//////////////////////////////////////////////////////

void myFrustum(float left, float right, float bot, float top, float nr, float fr)
{
}

//////////////////////////////////////////////////////
// FUNC:  myTranslate() 
//        postmultiplies ModelView by a translation matrix
//////////////////////////////////////////////////////

void myTranslate(float tx, float ty, float tz)
{
}

//////////////////////////////////////////////////////
// FUNC:  myRotate() 
//        postmultiplies ModelView by a rotation matrix
//////////////////////////////////////////////////////

void myRotate(float angle, float ax, float ay, float az)
{
}

//////////////////////////////////////////////////////
// FUNC:  myScale() 
//        postmultiplies ModelView by a scale matrix
//////////////////////////////////////////////////////

void myScale(float sx, float sy, float sz)
{
}

//////////////////////////////////////////////////////
// FUNC:  myMultMatrix() 
//        postmultiplies ModelView by the given matrix
//////////////////////////////////////////////////////

void myMultMatrix(Matrix m)
{
}

///////////////////////////////////////////////////////////
//    PROC: initZbuffer()
//    DOES: initializes Z-buffer
///////////////////////////////////////////////////////////

void initZbuffer() {
	const float LARGE = 1e37f;
	for (int x=0; x<MAXPIX; x++)
		for (int y=0; y<MAXPIX; y++)
			Zbuf[x][y] = LARGE;
}



