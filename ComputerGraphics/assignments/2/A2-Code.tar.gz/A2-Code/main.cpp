///////////////////////////////////////////////////////////////////
// FILE:      main.cpp
// CONTAINS:  template code for A2, CPSC 314, Jan 2009
///////////////////////////////////////////////////////////////////

#include "os.h"
#include <stdio.h>
#include <stdlib.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#define MAIN
#include "libDefs.h"

IMAGE *Image;    // pointer to linked list of images read in (for texture maps)
int Win[2];      // Win[0] == width, Win[1] = height of on-screen window
int Image_num;   // current number
STR Image_name;  // name for image series
IMAGE *CurrTex = NULL;  // pointer to current texture; used when binding textures

int RealWidth=600;
int RealHeight=400;
int VirtWidth;
int VirtHeight;
int PixelSize = 20;
int Grid = true;
char CurrScenario = 'i';
bool PCTexMap = false;             // flag for perspective correct texture mapping
void myReshape(int w, int h);


/////////////////////////////////////////////////////////////////
//	PROC:   SetPixel(x,y,r,g,b)
//	DOES:	sets the given pixel to the given color
/////////////////////////////////////////////////////////////////

void SetPixel(int x, int y, float r, float g, float b)
{
	if (x<0 || x>VirtWidth || y<0 || y>VirtHeight) {
		printf("ERROR:  attempting to set a pixel that is off-screen\n");
		return;
	}
	glColor3f(r,g,b);
	glBegin(GL_POINTS);
	glVertex2i(x,y);
	glEnd();
}

///////////////////////////////////////////////////////////////////
// FUNC:  DrawPixelGrid()
// DOES:  draws a series of lines representing the pixel grid
///////////////////////////////////////////////////////////////////																										

void DrawPixelGrid()
{
	glColor3f(0,0,0);
	float ymin = -0.5;
	float ymax = VirtHeight + 0.5;
	float xmin = -0.5;
	float xmax = VirtWidth + 0.5;
	for (float x=-0.5; x<=VirtWidth+1; x+=1) {
		glBegin(GL_LINES);
		glVertex2f(x,ymin);
		glVertex2f(x,ymax);
		glEnd();
	}
	for (float y=0-0.5; y<=VirtHeight+1; y+=1) {
		glBegin(GL_LINES);
		glVertex2f(xmin,y);
		glVertex2f(xmax,y);
		glEnd();
	}
}

///////////////////////////////////////////////////////////////////
// FUNC:  displayCallback()
// DOES:  clears screen, draws the world, swaps buffers
///////////////////////////////////////////////////////////////////																										

void displayCallback(void)
{
	extern void scenario_A();
	extern void scenario_B();
	extern void scenario_C();
	extern void scenario_D();
	extern void scenario_E();
	extern void scenario_F();
	extern void scenario_G();
	extern void scenario_H();
	extern void scenario_I();
	extern void initZbuffer();

	glClearColor(1,1,1,0);
	glClear( GL_COLOR_BUFFER_BIT );

	initZbuffer();
	switch(CurrScenario) {
	case 'a':
		scenario_A();
		break;
	case 'b':
		scenario_B();
		break;
	case 'c':
		scenario_C();
		break;
	case 'd':
		scenario_D();
		break;
	case 'e':
		scenario_E();
		break;
	case 'f':
		scenario_F();
		break;
	case 'g':
		scenario_G();
		break;
	case 'h':
		scenario_H();
		break;
	case 'i':
		scenario_I();
		break;
	default:
		break;
	}	
	if (Grid) DrawPixelGrid();
	glutSwapBuffers();
}

///////////////////////////////////////////////////////////////////
// FUNC:  keyCallback()
// DOES:  clears screen, draws the world, swaps buffers
///////////////////////////////////////////////////////////////////																										

void keyCallback(unsigned char key, int x, int y)
{
	if (key>='a' && key<='h') {
		printf("scenario '%c'\n",key);
		CurrScenario = key;
		glutPostRedisplay();
		return;
	}
	switch(key) {
	case 'H':
		printf("Keybindings:\n");
		printf("a-h  displays the given scenario\n");
		printf("H    help: lists keybindings\n");
		printf("q    quit\n");
		printf(".    toggles pixel grid on and off\n");
		printf("/    sets virtual pixel size to one, i.e., makes them real pixels\n");
		printf("<    decrease the virtual pixel size\n");
		printf(">    increase the virtual pixel size\n");
		break;
	case 'q':
		exit(0);
		break;
	case '.':
		Grid = !Grid;
		break;
	case '/':
		Grid = false;
		PixelSize = 1;
		glPointSize(PixelSize);
		printf("pixel size now %d\n",PixelSize);
		myReshape(RealWidth,RealHeight);
		break;
	case '<':
		if (PixelSize>1) {
			PixelSize--;
			glPointSize(PixelSize);
			printf("pixel size now %d\n",PixelSize);
			myReshape(RealWidth,RealHeight);
		}
		break;
	case '>':
		if (PixelSize<40) {
			PixelSize++;
			glPointSize(PixelSize);
			printf("pixel size now %d\n",PixelSize);
			myReshape(RealWidth,RealHeight);
		}
		break;
	case 't':
		PCTexMap = !PCTexMap;
		printf("perspective correct texture mapping ");
		if (PCTexMap)  printf("ON\n");
		else printf("OFF\n");
		break;
	default:
		break;
	}
	glutPostRedisplay();
}

///////////////////////////////////////////////////////////////////
// FUNC:  myReshape()
// DOES:  this is called if the on-screen window is resized
///////////////////////////////////////////////////////////////////																										

void myReshape(int w, int h)
{
   glViewport(0, 0, w, h);
   RealWidth = w; 
   RealHeight = h;
   float vw = RealWidth/PixelSize;
   float vh = RealHeight/PixelSize;
   VirtWidth = (int) vw;
   VirtHeight = (int) vh;
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(-0.5,vw,-0.5,vh,-1,1);
   glutPostRedisplay();
}

///////////////////////////////////////////////////////////////////
// FUNC:  idleCallback()
// DOES:  glut calls this when idle;  often used for animation
///////////////////////////////////////////////////////////////////																										

void idleCallback()
{
}

///////////////////////////////////////////////////////////////////
// FUNC:  init()
// DOES:  initializes default light source and surface material
///////////////////////////////////////////////////////////////////																										

void init(void) 
{
	glPointSize(PixelSize);
}

/////////////////////////////////////////////////////////////////
//	PROC:   setpixel(x,y,r,g,b)
//	DOES:	sets the given pixel to the given color
/////////////////////////////////////////////////////////////////

void setpixel(int x, int y, float r, float g, float b)
{
	glColor3f(r,g,b);
	glBegin(GL_POINTS);
	glVertex2i(x,y);
	glEnd();
}

///////////////////////////////////////////////////////////////////
// FUNC:  main()
// DOES:  intializes glut window, calls init(), then hands over control to glut
///////////////////////////////////////////////////////////////////																										

int main(int argc, char **argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
   glutInitWindowSize(RealWidth, RealHeight);
   glutCreateWindow("Assignment 2  CPSC 314");
   glutReshapeFunc(myReshape);
   glutDisplayFunc(displayCallback);
   glutKeyboardFunc(keyCallback);
   glutIdleFunc(idleCallback);
   init();
   glutMainLoop();
   return 0;
}
