/////////////////////////////////////////////////////////////
//	FILE: lib_math.c
//        Library of basic math functions
/////////////////////////////////////////////////////////////

#include "os.h"
#include <stdlib.h>
#include <math.h>
#include "libDefs.h"
#include "libMath.h"

//////////////////////////////////////////////////////////
//    PROC:  vPrint(FVEC)
//    DOES:  prints type FVEC
//////////////////////////////////////////////////////////

void vPrint(FVEC v)
{
  printf("%6.3f %6.3f %6.3f %6.3f\n",v[0],v[1],v[2],v[3]);
}

//////////////////////////////////////////////////////////
//    PROC:  vSub(ans,a,b)
//    DOES:  ans = a - b
//////////////////////////////////////////////////////////

void vSub(FVEC ans, FVEC a, FVEC b)
{
    int d;

    for (d=0; d<3; d++) {
		ans[d] = a[d] - b[d];
    }
}

//////////////////////////////////////////////////////////
//    PROC:  vAdd(ans,a,b)
//    DOES:  ans = a + b
//////////////////////////////////////////////////////////

void vAdd(FVEC ans, FVEC a, FVEC b)
{
    int d;

    for (d=0; d<3; d++) {
	ans[d] = a[d] + b[d];
    }
}

//////////////////////////////////////////////////////////
//    PROC:  vSize(v)
//    DOES:  returns size of vector v
//////////////////////////////////////////////////////////

float vSize(FVEC v)
{
    int d;
    float s = 0.0;

    for (d=0; d<3; d++) {
		s += v[d]*v[d];
    }
    return((float) sqrt(s));
}

//////////////////////////////////////////////////////////
//    PROC:  tmIden(m)
//    DOES:  sets 4x4 matrix m to the identity matrix
//////////////////////////////////////////////////////////

void tmIden(Matrix m)
{
    int i,j;

    for (i=0; i<4; i++) {
		for (j=0; j<4; j++) {
			m[i][j] = i==j;
		}
    }
}

//////////////////////////////////////////////////////////
//    PROC:  tmMultVec(ans, m, v)
//    DOES:  ans = m * v
//////////////////////////////////////////////////////////

void tmMultVec(FVEC a, Matrix m, FVEC v)
{
    int i,j;
    float s;

    for (i=0; i<4; i++) {
	s = 0.0;
	for (j=0; j<4; j++) 
	    s += m[i][j]*v[j];
	a[i] = s;
    }
}

//////////////////////////////////////////////////////////
//	 PROC:	tmPutcol(v,m,col)
//	 DOES:	copies vector into a column of matrix m
//////////////////////////////////////////////////////////

void tmPutcol(FVEC v, Matrix m, int col)
{
  int n;

  for (n=0; n<3; n++) {
    m[n][col] = v[n];
  }
}

//////////////////////////////////////////////////////////
//  PROC:	vXprod(v,a,b)
//  DOES:	calculates a crossproduct
//////////////////////////////////////////////////////////

void vXprod(FVEC v, FVEC a, FVEC b)
{
     v[0] = a[1]*b[2] - b[1]*a[2];
     v[1] = -a[0]*b[2] + b[0]*a[2];
     v[2] = a[0]*b[1] - b[0]*a[1];
}

//////////////////////////////////////////////////////////
//  PROC:	vXprodnorm(v,a,b)
//  DOES:	finds a normalized orthogonal vector
//////////////////////////////////////////////////////////

void vXprodnorm(FVEC v, FVEC a, FVEC b)
{
  vXprod(v,a,b);
  vNorm(v);
}

//////////////////////////////////////////////////////////
// PROC:	vNorm(v)
// DOES:	normalizes a vector
//////////////////////////////////////////////////////////

void vNorm(FVEC v)
{
  float s;

  s = 1.0f/(float) sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
  v[0] *= s;
  v[1] *= s;
  v[2] *= s;
}

//////////////////////////////////////////////////////////
//  PROC:	tmPrint()
//  DOES:	prints a transformation matrix
//////////////////////////////////////////////////////////

void tmPrint(Matrix m)
{
  int i,j;

  for (i=0; i<4; i++) {
    for (j=0; j<4; j++) {
	  printf("%6.3f ",m[i][j]);
	}
    printf("\n");
  }
}

//////////////////////////////////////////////////////////
//  PROC:	vCopy(a,b)
//  DOES:	copies b into a
//////////////////////////////////////////////////////////

void vCopy(FVEC a, FVEC b)
{
  int d;

  for (d=0; d<4; d++)
	 a[d] = b[d];
}

//////////////////////////////////////////////////////////
//  PROC: tmMultMat(ans,a,b)
//  DOES: multiplies two 4x4 matrices together
//////////////////////////////////////////////////////////

void tmMultMat(Matrix ans, Matrix a, Matrix b)
{
  int i,j,n;
  float s;

  for (i=0; i<4; i++) {
    for (j=0; j<4; j++) {
      s = 0.0;
      for (n=0; n<4; n++) {
    	s += a[i][n]*b[n][j];
      }
      ans[i][j] = s;
    }
  }
}

//////////////////////////////////////////////////////////
//  PROC: tmCopy(b,a)
//  DOES: copies matrix a into b
//////////////////////////////////////////////////////////

void tmCopy(Matrix b, Matrix a)
{
  int i,j;

  for (i=0; i<4; i++) {
    for (j=0; j<4; j++) {
      b[i][j] = a[i][j];
    }
  }
}

//////////////////////////////////////////////////////////
//    PROC: tmTranspose(tpmat, mat)
//    DOES: transposes a matrix
//////////////////////////////////////////////////////////

void tmTranspose(Matrix tpmat, Matrix mat)
{
  int i;
  int j;

  for (i=0; i<4; i++) {
    for (j=0; j<4; j++) {
      tpmat[i][j] = mat[j][i];
    }
  }
}

//////////////////////////////////////////////////////////
//	PROC:	tmRotkth(mat,k,th)
//	DOES:	determines a matrix from an axis k and an angle th
//////////////////////////////////////////////////////////

void tmRotkth(Matrix mat, FVEC k, float th)
{
    float cth, sth, vth;
    float kx, ky, kz;

    cth = (float) cos(th);
    vth = 1.0f-cth;
    sth = (float) sin(th);
    kx = k[0];
    ky = k[1];
    kz = k[2];
    tmIden(mat);
    mat[0][0] = kx*kx*vth + cth;
    mat[0][1] = ky*kx*vth - kz*sth;
    mat[0][2] = kz*kx*vth + ky*sth;
    mat[1][0] = kx*ky*vth + kz*sth;
    mat[1][1] = ky*ky*vth + cth;
    mat[1][2] = kz*ky*vth - kx*sth;
    mat[2][0] = kx*kz*vth - ky*sth;
    mat[2][1] = ky*kz*vth + kx*sth;
    mat[2][2] = kz*kz*vth + cth;
}

