////////////////////////////////////////////////////////////
//	FILE:		lib_image.c
//	CONTAINS:	functions for reading PPM images
////////////////////////////////////////////////////////////

#include "os.h"
#include <stdio.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <stdlib.h>

#include "libDefs.h"
#include "libImage.h"

//////////////////////////////////////////////////////////
//    PROC:  myMalloc()
//    DOES:  dynamic memory allocation, with error message if it fails
//////////////////////////////////////////////////////////

char *myMalloc(int size)
{
  char *buf;

  buf = (char *) malloc(size);
  if (!buf) {
    fprintf(stderr,"malloc() failure\n");
    exit(-1);
  }
  return(buf);
}

//////////////////////////////////////////////////////////
//  PROC:  find_image()
//  DOES:  finds image of the given name
//////////////////////////////////////////////////////////

IMAGE *find_image(char *name)
{
  IMAGE *image;

  for (image=Image; image; image=image->next) {
    if (!strcmp(name,image->name))
      return(image);
  }
  return((IMAGE *) NULL);
}

//////////////////////////////////////////////////////////
//    PROC:  newimage()
//    DOES:  creates a new image
//////////////////////////////////////////////////////////

IMAGE *newimage(char *name)
{
  IMAGE *i;

    // dynamically allocate space to store the image
  i = (IMAGE *) myMalloc(sizeof(IMAGE)); 
  strcpy(i->name,name);
  i->data = (unsigned char *) NULL;
  i->next = Image;

  Image = i;
  return(i);
}

///////////////////////////////////////////////////////
//	PROC:	readPPM()
//	DOES:	reads a ppm image, sets it up to be an OpenGL texture
///////////////////////////////////////////////////////

void readPPM(IMAGE *image, FILE *fp) {
	unsigned char c1, c2;

	fscanf(fp,"%c%c",&c1, &c2);
	if (c1!='P' || c2!='6') {
		printf("Unable to open file for texture '%s': not a PPM (raw) file (c1=%c, c2=%c).\n",
			image->name,c1,c2);
		return;
	}
	int xsize, ysize, maxval;
	fscanf(fp,"%d%d%d",&xsize, &ysize, &maxval);
	printf("%s: %d x %d image\n",image->name,xsize,ysize);
	image->xsize = xsize;
	image->ysize = ysize;
	fgetc(fp);           // discard white-space character
	if (image->data)     // discard old image, if any
		free(image->data);
	int size = xsize*ysize*3;
	image->data = (unsigned char *) malloc(size);
	int count=0;
	int rv = fread(image->data, 1, size, fp);
	return;
}

/////////////////////////////////////////////////////////////
//	PROC:   getTexel(image, u, v, r, g, b)
//	DOES:	gets a pixel from one of the texture images
/////////////////////////////////////////////////////////////

void getTexel(IMAGE *i, float u, float v, float &r, float &g, float &b)
{
	if (i->clamp) {     // clamp out-of-bounds accesses
		if (u>1) u=1;
		if (u<0) u=0;
		if (v>1) v=1;
		if (v<0) v=0;
	} else {            // wrap-around out-of-bounds accesses
		if (u>1) u = u - int(u);
		else if (u<0) u = 1 + u - int(u);
		if (v>1) v = v - int(v);
		else if (v<0) v = 1 + v - int(v);
	}
	  // compute pixel coords from texture coords
	int x = int(u*(i->xsize - 1));
	int y = int(v*(i->ysize - 1));
	  // get the pixel colour, convert RGB values to the range [0-1]
	unsigned char *p = i->data + 3*(y * i->xsize + x);
	r = *p/255.0f;
	g = *(p+1)/255.0f;
	b = *(p+2)/255.0f;
}

/////////////////////////////////////////
//	PROC:   myBindTexture	(name)
//	DOES:	binds current texture to the image with the given name.
//          Reads in the image if this hasn't been done yet.
/////////////////////////////////////////

void myBindTexture(char *name)
{
	extern IMAGE *CurrTex;

	IMAGE *i = find_image(name);      // check to see if the image has been previously read in
	if (!i) {
		  FILE *fp = fopen(name,"r"); 
		  if(!fp) {
			  printf("Unable to open input file\n");
			  return;
		  }
		  IMAGE *image = newimage(name);
		  strcpy(image->name,name);
		  image->clamp = false;
		  readPPM(image, fp);
		  fclose(fp);
		  i = image;
	}
	CurrTex = i;
}

/////////////////////////////////////////
//	PROC:	save_image
//	DOES:	saves the current image to a ppm file
/////////////////////////////////////////

void save_image()
{
  FILE *fp;
  STR fname;
  const int maxVal=255;
  register int y;
  unsigned char *pixels;

  sprintf(fname,"%s%d", Image_name, Image_num);
  printf("Saving image %s\n", fname);
  Image_num++;
  fp = fopen(fname,"w");
  if (!fp) {
	printf("Unable to open file '%s'\n",fname);
	return;
  }
  fprintf(fp, "P6\n");
  fprintf(fp, "%d %d\n", Win[0], Win[1]);
  fprintf(fp, "%d\n", maxVal);

  pixels = new unsigned char [3*Win[0]];
  for ( y = Win[1]-1; y>=0; y-- ) {
	glReadPixels(0,y,Win[0],1,GL_RGB,GL_UNSIGNED_BYTE, (GLvoid *) pixels);
    fwrite(pixels, 3, Win[0], fp);
  }
  fclose(fp);
}




