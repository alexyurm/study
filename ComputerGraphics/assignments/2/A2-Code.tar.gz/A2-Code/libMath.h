/////////////////////////////////////////////////////////////
//	FILE: lib_math.h
//        prototypes for lib_math.cpp
/////////////////////////////////////////////////////////////

  // NOTE:  for all the following functions, you should ensure
  //        that the answer paramater is different than the
  //        input parameters.  E.g., do not use:
  //           tmMultVec( v, m, v)   to compute  v = m*v 

  // functions for 4x4 transformation matrices

void tmIden(Matrix m);          // set to identity
void tmMultVec(FVEC a, Matrix m, FVEC v);        // multiply by vector v
void tmMultMat(Matrix ans, Matrix a, Matrix b);  // multiply a * b
void tmCopy(Matrix b, Matrix a);                 // b <- a
void tmPrint(Matrix m);                          // print 
void tmTranspose(Matrix tpmat, Matrix mat);      // tpmat = transpose(mat)
void tmGetcol(FVEC v, Matrix m, int n);          // v = nth column of m, n=[0,3]
void tmPutcol(FVEC v, Matrix m, int n);          // m[][n] = v,   n[0,3]
void tmRotkth(Matrix mat, FVEC k, float th);     // matrix for rotating th radians
                                                 //   about a normalized vector k

  // functions for 3-vectors
  //   note:  FVEC is really a 4-vector, so the last element, v[3] is ignored
  //          by the following functions

void vPrint(FVEC v);                     // print vector
void vXprod(FVEC v, FVEC a, FVEC b);     // v = a x b
void vXprodnorm(FVEC v, FVEC a, FVEC b); // v = a x b, then normalized
void vNorm(FVEC v);                      // normalizes v
void vCopy(FVEC a, FVEC b);              // a = b
void vSub(FVEC ans, FVEC a, FVEC b);     // ans = a - b
void vAdd(FVEC ans, FVEC a, FVEC b);     // ans = a + b
float vSize(FVEC v);                     // returns magnitude of v
