/** Source code example for "A Practical Introduction to Data
    Structures and Algorithm Analysis, 3rd Edition (Java)" 
    by Clifford A. Shaffer
    Copyright 2008-2011 by Clifford A. Shaffer
*/

import java.io.*;

public class BufferTest {

  public static void main(String args[]) throws IOException {
    BufferPoolADT it = new BufferPool(10, 10);
  }
}
